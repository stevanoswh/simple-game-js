// Neon Drift (Canvas game) - single file
// Kids edit only small TODO sections.

// ===== Canvas setup =====
const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

const W = canvas.width;
const H = canvas.height;

// ===== UI =====
const uiScore = document.getElementById("score");
const uiDanger = document.getElementById("danger");
const uiCombo = document.getElementById("combo");

const panel = document.getElementById("panel");
const panelTitle = document.getElementById("panelTitle");
const panelText = document.getElementById("panelText");
const startBtn = document.getElementById("startBtn");
const restartBtn = document.getElementById("restartBtn");

// ===== Settings (Mission 1 changes 3 numbers) =====
const SETTINGS = {
  playerSpeed: 240,      // TODO: Mission 1 (kids) change to 280
  dashCooldown: 1.25,    // TODO: Mission 1 (kids) change to 1.0
  coinScore: 30,         // TODO: Mission 1 (kids) change to 40
  maxCombo: 4.0,
  enemySpawnRate: 0.95,  // lower = more enemies
  coinSpawnRate: 0.70,
  powerSpawnRate: 7.0,   // seconds per powerup
};

function rand(a, b) { return a + Math.random() * (b - a); }
function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

// ===== Input =====
const keys = new Set();
window.addEventListener("keydown", (e) => {
  if (["ArrowUp","ArrowDown","ArrowLeft","ArrowRight"," "].includes(e.key)) e.preventDefault();
  keys.add(e.key.toLowerCase());
  if (e.key.toLowerCase() === "p") togglePause();
  if (e.key.toLowerCase() === "r") restart();
});
window.addEventListener("keyup", (e) => keys.delete(e.key.toLowerCase()));

// ===== Game state =====
let state = null;
let running = false;
let paused = false;
let lastT = 0;

const player = { x: W/2, y: H/2, r: 13, vx:0, vy:0, dash:0, dashCd:0 };

function makeEnemy() {
  const side = Math.floor(rand(0, 4));
  const r = rand(11, 18);
  let x, y;
  if (side === 0) { x = -r; y = rand(0, H); }
  if (side === 1) { x = W + r; y = rand(0, H); }
  if (side === 2) { x = rand(0, W); y = -r; }
  if (side === 3) { x = rand(0, W); y = H + r; }
  const ang = Math.atan2(player.y - y, player.x - x);
  const sp = rand(110, 170) + state.danger * 6;
  return { x, y, r, vx: Math.cos(ang)*sp, vy: Math.sin(ang)*sp };
}

function spawnCoin() {
  // simple random spawn (bonus can change)
  const r = 9;
  let x = rand(30, W-30);
  let y = rand(30, H-30);

  // avoid spawning right on top of player
  const dx = x - player.x, dy = y - player.y;
  if (Math.hypot(dx, dy) < 120) { x = rand(30, W-30); y = rand(30, H-30); }

  state.coins.push({ x, y, r, t: 0 });
}

function spawnPowerup() {
  const r = 12;
  const x = rand(40, W-40);
  const y = rand(40, H-40);
  const kind = Math.random() < 0.6 ? "boost" : "freeze"; // B or F
  state.powers.push({ x, y, r, kind, t: 0 });
}

function getCoinGain() {
  // ===== Kids will add 1 feature here (small) =====
  // TODO 4 (kids code, 2-3 lines):
  // Make coin value increase when danger is high.
  // Example: return SETTINGS.coinScore + state.danger * 2;
  return SETTINGS.coinScore;
}

function restart() {
  state = {
    t: 0,
    score: 0,
    danger: 0,
    combo: 1.0,
    boost: 0,     // seconds
    freeze: 0,    // seconds
    shake: 0,
    over: false,

    enemies: [],
    coins: [],
    powers: [],

    enemyTimer: 0,
    coinTimer: 0,
    powerTimer: 0,

    highScore: 0,
  };

  player.x = W/2; player.y = H/2; player.vx = 0; player.vy = 0;
  player.dash = 0; player.dashCd = 0;

  // BONUS TODO: High score (kids can add localStorage here)
  // state.highScore = Number(localStorage.getItem("neon_highscore") || 0);

  // Start with some coins
  for (let i=0;i<4;i++) spawnCoin();

  panelTitle.textContent = "Neon Drift";
  panelText.innerHTML = "Move with <b>WASD</b>/<b>Arrows</b> • Dash with <b>Shift</b> • Pause with <b>P</b>";
  panel.style.display = "grid";
  running = false;
  paused = false;
  draw(0);
}

function start() {
  if (!state) restart();
  running = true;
  paused = false;
  panel.style.display = "none";
  lastT = performance.now();
  requestAnimationFrame(loop);
}

function togglePause() {
  if (!running || state.over) return;
  paused = !paused;
  if (paused) {
    panelTitle.textContent = "Paused";
    panelText.innerHTML = "Press <b>P</b> to continue.";
    panel.style.display = "grid";
  } else {
    panel.style.display = "none";
    lastT = performance.now();
    requestAnimationFrame(loop);
  }
}

function gameOver() {
  state.over = true;
  running = false;

  const s = Math.floor(state.score);
  // BONUS TODO: High score (kids can save to localStorage here)
  // if (s > state.highScore) {
  //   state.highScore = s;
  //   localStorage.setItem("neon_highscore", String(s));
  // }

  panelTitle.textContent = "Game Over!";
  panelText.innerHTML =
    "Score: <b>" + Math.floor(state.score) + "</b><br/>" +
    "Best: <b>" + state.highScore + "</b><br/><br/>" +
    "Press <b>R</b> or click Restart.";
  panel.style.display = "grid";
}

function hitCircle(ax, ay, ar, bx, by, br) {
  const dx = ax - bx, dy = ay - by;
  return (dx*dx + dy*dy) <= (ar + br) * (ar + br);
}

// ===== Main loop =====
function loop(t) {
  if (!running || paused) return;
  const dt = clamp((t - lastT) / 1000, 0, 0.033);
  lastT = t;

  update(dt);
  draw(dt);

  if (running) requestAnimationFrame(loop);
}

function update(dt) {
  state.t += dt;

  // Danger grows slowly over time
  state.danger = Math.floor(state.t / 6);

  // Timers
  state.enemyTimer -= dt;
  state.coinTimer -= dt;
  state.powerTimer -= dt;

  // Spawn enemies/coins/powerups
  if (state.enemyTimer <= 0) {
    state.enemies.push(makeEnemy());
    state.enemyTimer = SETTINGS.enemySpawnRate - Math.min(0.45, state.danger * 0.03);
  }
  if (state.coinTimer <= 0) {
    spawnCoin();
    state.coinTimer = SETTINGS.coinSpawnRate;
  }
  if (state.powerTimer <= 0) {
    spawnPowerup();
    state.powerTimer = SETTINGS.powerSpawnRate;
  }

  // Cooldowns
  player.dashCd = Math.max(0, player.dashCd - dt);
  player.dash = Math.max(0, player.dash - dt);

  // Power timers
  state.boost = Math.max(0, state.boost - dt);
  // TODO: Mission 5 (kids) reduce freeze timer:
  // state.freeze = Math.max(0, state.freeze - dt);

  // Movement
  const up = keys.has("w") || keys.has("arrowup");
  const dn = keys.has("s") || keys.has("arrowdown");
  const lf = keys.has("a") || keys.has("arrowleft");
  const rt = keys.has("d") || keys.has("arrowright");

  let ax = 0, ay = 0;
  if (up) ay -= 1;
  if (dn) ay += 1;
  if (lf) ax -= 1;
  if (rt) ax += 1;

  const len = Math.hypot(ax, ay) || 1;
  ax /= len; ay /= len;

  const baseSpeed = SETTINGS.playerSpeed * (state.boost > 0 ? 1.25 : 1.0);
  const dashSpeed = 560;

  // Dash
  if (keys.has("shift") && player.dashCd <= 0) {
    player.dash = 0.15;
    player.dashCd = SETTINGS.dashCooldown;
  }

  const sp = (player.dash > 0) ? dashSpeed : baseSpeed;
  player.x += ax * sp * dt;
  player.y += ay * sp * dt;

  // Clamp to arena
  player.x = clamp(player.x, player.r, W - player.r);
  player.y = clamp(player.y, player.r, H - player.r);

  // Enemies
  for (const e of state.enemies) {

    // TODO: Mission 5 (kids) if freeze is active, skip enemy movement:
    // if (state.freeze > 0) {
    //   continue;
    // }

    e.x += e.vx * dt;
    e.y += e.vy * dt;

    // ===== Kids will add 1 feature here (small) =====
    // TODO 1 (kids code, 6-8 lines):
    // Make enemies bounce off the walls.
    // (Paste the bounce code from the PDF.)
    // --------------------------------------

    // Soft pull to player (makes it feel alive)
    const ang = Math.atan2(player.y - e.y, player.x - e.x);
    e.vx += Math.cos(ang) * (10 + state.danger) * dt;
    e.vy += Math.sin(ang) * (10 + state.danger) * dt;

    // Collision: player loses
    if (hitCircle(player.x, player.y, player.r, e.x, e.y, e.r)) {
      gameOver();
      return;
    }
  }

  // Coins
  for (let i = state.coins.length - 1; i >= 0; i--) {
    const coin = state.coins[i];
    coin.t += dt;

    // ===== Kids will add 1 feature here (small) =====
    // TODO 2 (kids code, ~10-12 lines):
    // If boost is active, coins fly to the player.
    // (Paste the magnet code from the PDF.)
    // --------------------------------------

    if (hitCircle(player.x, player.y, player.r, coin.x, coin.y, coin.r)) {
      state.coins.splice(i, 1);

      // score
      state.combo = Math.min(SETTINGS.maxCombo, state.combo + 0.12);
      state.score += getCoinGain() * state.combo;

      // little shake
      state.shake = 0.10;
    }
  }

  // Powerups
  for (let i = state.powers.length - 1; i >= 0; i--) {
    const pu = state.powers[i];
    pu.t += dt;

    if (hitCircle(player.x, player.y, player.r, pu.x, pu.y, pu.r)) {
      state.powers.splice(i, 1);

      if (pu.kind === "boost") {
        state.boost = 3.5;
        state.score += 50;
      } else if (pu.kind === "freeze") {
        // TODO: Mission 5 (kids) give freeze effect:
        // state.freeze = 3.0;
        // state.score += 70;
      }
    }
  }

  // Combo slowly decays
  state.combo = Math.max(1.0, state.combo - 0.35 * dt);

  // Update UI
  uiScore.textContent = String(Math.floor(state.score));
  uiDanger.textContent = String(state.danger);
  uiCombo.textContent = state.combo.toFixed(1) + "x";
}

function draw(dt) {
  // screen shake
  const shake = state ? state.shake : 0;
  let sx = 0, sy = 0;
  if (shake > 0) {
    if (state) state.shake = Math.max(0, state.shake - dt);
    sx = rand(-10, 10) * shake;
    sy = rand(-10, 10) * shake;
  }

  ctx.save();
  ctx.clearRect(0,0,W,H);
  ctx.translate(sx, sy);

  // Background grid
  ctx.globalAlpha = 0.12;
  ctx.strokeStyle = "#7ca7ff";
  for (let x=0;x<=W;x+=40){
    ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke();
  }
  for (let y=0;y<=H;y+=40){
    ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke();
  }
  ctx.globalAlpha = 1;

  // Arena border glow
  ctx.strokeStyle = "rgba(124,167,255,0.55)";
  ctx.lineWidth = 3;
  ctx.strokeRect(8,8,W-16,H-16);

  // Coins
  for (const c of (state?.coins || [])) {
    drawCoin(c.x, c.y, c.r);
  }

  // Powerups
  for (const p of (state?.powers || [])) {
    drawPower(p.x, p.y, p.r, p.kind);
  }

  // Enemies
  for (const e of (state?.enemies || [])) {
    drawEnemy(e.x, e.y, e.r);
  }

  // Player
  drawPlayer(player.x, player.y, player.r);

  // Status text
  if (state) {
    if (state.boost > 0) drawBadge(20, 22, "BOOST", "rgba(124,255,178,0.25)", "#7cffb2");
    if (state.freeze > 0) drawBadge(110, 22, "FREEZE", "rgba(124,167,255,0.25)", "#7ca7ff");
  }

  ctx.restore();
}

// ===== Drawing helpers =====
function drawPlayer(x,y,r){
  const glow = (state && state.boost > 0) ? "rgba(124,255,178,0.45)" : "rgba(124,167,255,0.45)";
  ctx.beginPath();
  ctx.fillStyle = glow;
  ctx.arc(x,y,r+8,0,Math.PI*2);
  ctx.fill();

  ctx.beginPath();
  ctx.fillStyle = "#f2f3ff";
  ctx.arc(x,y,r,0,Math.PI*2);
  ctx.fill();
}

function drawEnemy(x,y,r){
  ctx.beginPath();
  ctx.fillStyle = "rgba(255,92,122,0.35)";
  ctx.arc(x,y,r+8,0,Math.PI*2);
  ctx.fill();

  ctx.beginPath();
  ctx.fillStyle = "#ff5c7a";
  ctx.arc(x,y,r,0,Math.PI*2);
  ctx.fill();
}

function drawCoin(x,y,r){
  ctx.beginPath();
  ctx.fillStyle = "rgba(255,218,124,0.30)";
  ctx.arc(x,y,r+7,0,Math.PI*2);
  ctx.fill();

  ctx.beginPath();
  ctx.fillStyle = "#ffda7c";
  ctx.arc(x,y,r,0,Math.PI*2);
  ctx.fill();
}

function drawPower(x,y,r,kind){
  ctx.beginPath();
  const col = kind === "boost" ? "#7cffb2" : "#7ca7ff";
  ctx.fillStyle = "rgba(255,255,255,0.16)";
  ctx.arc(x,y,r+8,0,Math.PI*2);
  ctx.fill();

  ctx.beginPath();
  ctx.fillStyle = col;
  ctx.arc(x,y,r,0,Math.PI*2);
  ctx.fill();

  ctx.fillStyle = "#060712";
  ctx.font = "bold 12px system-ui";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(kind === "boost" ? "B" : "F", x, y+0.5);
}

function drawBadge(x,y,label,bg,fg){
  ctx.save();
  ctx.font = "700 12px system-ui";
  ctx.textAlign="left";ctx.textBaseline="middle";
  const w = ctx.measureText(label).width + 18;
  ctx.fillStyle = bg;
  roundRect(x,y-10,w,20,10,true,false);
  ctx.strokeStyle = fg;
  ctx.globalAlpha = 0.8;
  roundRect(x,y-10,w,20,10,false,true);
  ctx.globalAlpha = 1;
  ctx.fillStyle = fg;
  ctx.fillText(label, x+9, y);
  ctx.restore();
}

function roundRect(x,y,w,h,r,fill,stroke){
  ctx.beginPath();
  ctx.moveTo(x+r,y);
  ctx.arcTo(x+w,y,x+w,y+h,r);
  ctx.arcTo(x+w,y+h,x,y+h,r);
  ctx.arcTo(x,y+h,x,y,r);
  ctx.arcTo(x,y,x+w,y,r);
  if (fill) ctx.fill();
  if (stroke) ctx.stroke();
}

// ===== Buttons =====
startBtn.addEventListener("click", start);
restartBtn.addEventListener("click", () => { restart(); start(); });

// ===== Boot =====
restart();
